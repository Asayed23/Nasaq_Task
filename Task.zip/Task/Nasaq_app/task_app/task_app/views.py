from django.shortcuts import render
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_protect
from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from .forms import LoginForm



def login_page(request):
    form = LoginForm(request.POST or None)
    context = {
        "form": form
    }

    if form.is_valid():

        username = str(form.cleaned_data.get("username").lower())
        password = str(form.cleaned_data.get("password"))
        user = authenticate(request, username=username, password=password)
        print(user)
        # Check user authentication status
        if user is not None:

            login(request, user)
            context['form'] = LoginForm()
            return redirect("/new_task/")

        else:
            # Check user existence
            if not User.objects.filter(username=username).exists():
                context.update({"user_na": "success"}) # alarm if user is not exist
            else:
                context.update({"wrong_pass": "success"}) # alarm if password is wrong but user exist

    return render(request, "login.html", context)

