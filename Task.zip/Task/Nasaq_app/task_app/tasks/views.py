from django.shortcuts import render
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_protect
from django.contrib.admin.views.decorators import staff_member_required
from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.contrib.auth.models import User

from django.db.models import Q

from .models import task_profile

@login_required(login_url='/')
def new_task(request):
    tasks = task_profile.objects.all
    context={"tasks": tasks}
    # --------- search by task_status

    if request.method == 'POST' and ("search" in request.POST):
        task_status = request.POST.get("task_status")
        task_id= task_profile.objects.filter(task_status=task_status)
        task_id_values=task_profile.objects.filter(task_status=task_status).values()
        context.update({"task_id":task_id,"task_status":task_id_values[0]["task_status"]})

    # --------- search by id
    if request.method == 'POST' and ("search_id" in request.POST):
        id = request.POST.get("task_id")
        task_id= task_profile.objects.filter(Q(id=id)|Q(linked_id_task=id))
        task_id_values=task_profile.objects.filter(Q(id=id)|Q(linked_id_task=id)).values()
        context.update({"task_id":task_id,"task_status":task_id_values[0]["task_status"]})

    # -----------------    update title
    if request.method == 'POST' and ("update_title" in request.POST):
        id = request.POST.get("task_id")
        new_title = request.POST.get("new_title")
        task_id_values = task_profile.objects.filter(id=id).values()
        # ----------- check task status
        if task_id_values[0]["task_status"] == "new":
            task_profile.objects.filter(id=id).update(title=new_title)
            context.update({"task_status": "new"})
        else:
            context.update({"task_status": "new", "wrong_status": "wrong_status"})

    # -----------------    update description
    if request.method == 'POST' and ("update_description" in request.POST):
        id = request.POST.get("task_id")
        new_description = request.POST.get("new_description")
        task_id_values = task_profile.objects.filter(id=id).values()
        # ----------- check task status
        if task_id_values[0]["task_status"] == "new":
            task_profile.objects.filter(id=id).update(description=new_description)
            context.update({"task_status": "new"})
        else:
            context.update({"task_status":"new","wrong_status":"wrong_status"})

    # -----------------    link two tasks
    if request.method == 'POST' and ("link" in request.POST):
        id = request.POST.get("task1")
        id2 = request.POST.get("task2")
        task_id_values = task_profile.objects.filter(id=id).values()
        if task_id_values[0]["task_status"] == "inprogress":
            task_profile.objects.filter(id=id).update(linked_id_task=id2)
            task_profile.objects.filter(id=id2).update(linked_id_task=id)
            context.update({"task_status": "inprogress"})
        else:
            context.update({"task_status":"inprogress","wrong_status":"wrong_status"})

    return render(request, "new_task.html" , context)