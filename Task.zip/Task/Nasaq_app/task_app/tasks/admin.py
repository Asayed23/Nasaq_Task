from django.contrib import admin
from.models import task_profile
# Register your models here.
admin.site.register(task_profile)