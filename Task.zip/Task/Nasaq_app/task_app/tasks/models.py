from django.db import models

# Create your models here.
class task_profile(models.Model):
    new="new"
    inprogress="inprogress"
    done="done"
    task_status_choices = [(new,"new"),(inprogress,"inprogress"),(done,"done")]
    title = models.CharField(blank=False, max_length=100)
    description = models.TextField(max_length=500,
                                  blank=False, null=True)
    task_status = models.CharField(max_length=30,
                                  choices=task_status_choices,
                                  blank=False, null=True)
    linked_id_task=models.IntegerField(blank=True,null=True)