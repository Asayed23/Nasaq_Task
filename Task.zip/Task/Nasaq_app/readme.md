# Nasaq Task 
	is simple python dango application
# installation
	pip install django
	
# RUN
	1-open terminal window iniside task_app folder then write the below commands
		python manage.py migrate
		python manage.py runserver
	2- open browser and type 127.0.0.0:8000 

# How to use the application 
the landing page is login page	
	the normal user is
		username=  nasaq ( you can use it small or capital letter) 
		password=  Nasaq_1234
	the admin user is 
		username = nasaq_admin ( you can use it small or capital letter)
		password=  Nasaq_1234
		
	once you press login you will go to the task app 
	
The task_app page contains
	search by task
	search by id ( either task id or linked task id)
	edit title 
	edit description
	link two tasks
